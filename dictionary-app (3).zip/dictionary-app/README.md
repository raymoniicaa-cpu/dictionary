# Lexicon — Dictionary Web App

A fast, database-free dictionary built with Next.js, TypeScript, and Tailwind CSS. Definitions
come from [DictionaryAPI.dev](https://dictionaryapi.dev); favorites, search history, and theme
are stored in the browser's `localStorage`. No backend, no database, no login.

## Features

- Word search with definitions, pronunciation audio, examples, synonyms, and antonyms
- **Scan & Translate**: photograph a page, sign, or label — Google Cloud Vision extracts the
  text, tap any word to look it up, or translate the whole passage with Google Cloud Translation
- Favorites ("shelf") and recent search history, persisted in local storage
- Light/dark mode
- Word of the day and an alphabet "thumb index" for quick browsing
- Copy definition / share word
- Installable PWA (manifest + icon)
- Pages: Home, Scan, Favorites, About, and a custom 404

## Run locally

```bash
npm install
cp .env.local.example .env.local   # then fill in GOOGLE_API_KEY (see below)
npm run dev
```

Open http://localhost:3000.

### Setting up the Google API key (for Scan & Translate)

The Scan & Translate page needs a Google Cloud API key with two APIs enabled. Without it, every
other page works fine — only `/scan` and the entry card's translate button will show a
"not configured" message.

1. Create or open a project at https://console.cloud.google.com
2. Enable **Cloud Vision API** and **Cloud Translation API** (APIs & Services > Library)
3. Create an API key under APIs & Services > Credentials
4. Restrict the key to those two APIs (Credentials > your key > API restrictions) — this limits
   blast radius if the key ever leaks
5. Set `GOOGLE_API_KEY` to that value in `.env.local` for local dev, and again in your Vercel
   project's **Settings > Environment Variables** for Production/Preview before deploying
6. Both APIs have a Google Cloud free tier (1,000 units/month for Vision, 500,000 characters/month
   for Translation as of this writing); usage beyond that is billed to your GCP project, so set a
   budget alert if you're concerned about cost

The key is only ever read server-side inside `src/app/api/ocr` and `src/app/api/translate` — it
is never sent to the browser.

## Deploy to Vercel

**Option A — Vercel dashboard**
1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. Go to https://vercel.com/new and import the repo.
3. Vercel auto-detects Next.js.
4. Add `GOOGLE_API_KEY` under Settings > Environment Variables if you want Scan & Translate to
   work (optional — the rest of the app works without it).
5. Click Deploy.

**Option B — Vercel CLI**
```bash
npm install -g vercel
vercel
vercel env add GOOGLE_API_KEY   # optional, for Scan & Translate
vercel --prod
```

No database is required either way — the app calls DictionaryAPI.dev directly from the browser,
and Google Cloud Vision/Translation from two small server-side API routes.

## Project structure

```
src/
  app/
    page.tsx                Home (search + entry display)
    scan/page.tsx             Scan & Translate
    favorites/page.tsx        Shelf (saved words)
    about/page.tsx             About
    not-found.tsx                404
    layout.tsx                   Root layout, fonts, header, footer
    globals.css                   Tailwind + design tokens
    api/
      ocr/route.ts                Google Cloud Vision text detection
      translate/route.ts          Google Cloud Translation
  components/                 SearchBox, EntryCard, AlphabetRail, ScanCapture,
                                TranslatePanel, etc.
  lib/
    dictionary.ts              API client + types
    storage.ts                  localStorage hooks (favorites, history, theme)
    seedWords.ts                Curated word list for alphabet rail / word of the day
    google.ts                    Server-only Google API key helper
    languages.ts                  Language list for the translate selector
public/
  manifest.json, icon.svg     PWA assets
.env.local.example            Template for GOOGLE_API_KEY
```
