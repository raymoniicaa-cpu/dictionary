import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: {
          DEFAULT: "#F7F3E9",
          dark: "#15140F",
        },
        ink: {
          DEFAULT: "#211F1B",
          soft: "#5B5749",
          dark: "#EDE7D6",
          darksoft: "#A8A18C",
        },
        rule: {
          DEFAULT: "#D9D0B8",
          dark: "#322F26",
        },
        stamp: "#AE3B2E",
        moss: "#586B52",
        mossdark: "#8FAE87",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-source-serif)", "serif"],
        mono: ["var(--font-jetbrains)", "monospace"],
      },
      backgroundImage: {
        grain: "url('/grain.svg')",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "stamp-in": {
          "0%": { opacity: "0", transform: "scale(1.4) rotate(-6deg)" },
          "60%": { opacity: "1", transform: "scale(0.96) rotate(-2deg)" },
          "100%": { opacity: "1", transform: "scale(1) rotate(-2deg)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s ease-out both",
        "stamp-in": "stamp-in 0.4s ease-out both",
      },
    },
  },
  plugins: [],
};
export default config;
