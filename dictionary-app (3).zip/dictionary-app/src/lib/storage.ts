"use client";

import { useCallback, useEffect, useState } from "react";

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full or unavailable - fail silently, app still works
  }
}

const FAVORITES_KEY = "lexicon:favorites";
const HISTORY_KEY = "lexicon:history";
const THEME_KEY = "lexicon:theme";
const MAX_HISTORY = 25;

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    setFavorites(readStorage<string[]>(FAVORITES_KEY, []));
  }, []);

  const isFavorite = useCallback(
    (word: string) => favorites.includes(word.toLowerCase()),
    [favorites]
  );

  const toggleFavorite = useCallback((word: string) => {
    const lower = word.toLowerCase();
    setFavorites((prev) => {
      const next = prev.includes(lower)
        ? prev.filter((w) => w !== lower)
        : [lower, ...prev];
      writeStorage(FAVORITES_KEY, next);
      return next;
    });
  }, []);

  const removeFavorite = useCallback((word: string) => {
    const lower = word.toLowerCase();
    setFavorites((prev) => {
      const next = prev.filter((w) => w !== lower);
      writeStorage(FAVORITES_KEY, next);
      return next;
    });
  }, []);

  return { favorites, isFavorite, toggleFavorite, removeFavorite };
}

export function useHistory() {
  const [history, setHistory] = useState<string[]>([]);

  useEffect(() => {
    setHistory(readStorage<string[]>(HISTORY_KEY, []));
  }, []);

  const addToHistory = useCallback((word: string) => {
    const lower = word.toLowerCase();
    setHistory((prev) => {
      const next = [lower, ...prev.filter((w) => w !== lower)].slice(0, MAX_HISTORY);
      writeStorage(HISTORY_KEY, next);
      return next;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    writeStorage(HISTORY_KEY, []);
  }, []);

  return { history, addToHistory, clearHistory };
}

export type Theme = "light" | "dark";

export function useTheme() {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    const stored = readStorage<Theme | null>(THEME_KEY, null);
    const preferred =
      stored ??
      (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    setTheme(preferred);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    writeStorage(THEME_KEY, theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  }, []);

  return { theme, toggleTheme };
}
