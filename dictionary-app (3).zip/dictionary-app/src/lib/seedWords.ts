/**
 * A small curated set of interesting words per letter. DictionaryAPI.dev has
 * no "browse" endpoint, so this seed list powers the alphabet rail's quick
 * picks and the word-of-the-day feature without needing a backend.
 */
export const SEED_WORDS: Record<string, string[]> = {
  a: ["apricity", "aplomb", "aurora", "anomaly"],
  b: ["bewilder", "brindle", "bivouac", "bramble"],
  c: ["cascade", "chimera", "cobalt", "crepuscular"],
  d: ["denouement", "diaphanous", "dovetail", "dusk"],
  e: ["effervescent", "ephemeral", "elixir", "echo"],
  f: ["fathom", "filigree", "flourish", "fern"],
  g: ["gossamer", "gambit", "glower", "gravity"],
  h: ["halcyon", "harbinger", "hush", "hollow"],
  i: ["incandescent", "ineffable", "ivory", "isthmus"],
  j: ["jubilant", "juxtapose", "jagged", "jovial"],
  k: ["kaleidoscope", "keystone", "kindle", "kinship"],
  l: ["labyrinth", "lambent", "lull", "luminous"],
  m: ["mosaic", "meander", "mellifluous", "mirage"],
  n: ["nebula", "nostalgia", "nuance", "nimbus"],
  o: ["obsidian", "ochre", "opaque", "overture"],
  p: ["paradox", "petrichor", "plume", "penumbra"],
  q: ["quaint", "quintessence", "quiver", "quell"],
  r: ["resonance", "ripple", "rustic", "reverie"],
  s: ["serendipity", "solstice", "susurrus", "sundry"],
  t: ["tangent", "tessellate", "threshold", "twilight"],
  u: ["umbra", "undulate", "unfurl", "utopia"],
  v: ["verdant", "vestige", "vortex", "vermillion"],
  w: ["whimsy", "wanderlust", "wisteria", "wane"],
  x: ["xenial"],
  y: ["yearn", "yonder", "yield"],
  z: ["zenith", "zephyr", "zest"],
};

export const ALPHABET = "abcdefghijklmnopqrstuvwxyz".split("");

export function wordOfTheDay(): string {
  const all = Object.values(SEED_WORDS).flat();
  const day = Math.floor(Date.now() / 86_400_000);
  return all[day % all.length];
}
