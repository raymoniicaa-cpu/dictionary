export interface Phonetic {
  text?: string;
  audio?: string;
}

export interface Definition {
  definition: string;
  example?: string;
  synonyms: string[];
  antonyms: string[];
}

export interface Meaning {
  partOfSpeech: string;
  definitions: Definition[];
  synonyms: string[];
  antonyms: string[];
}

export interface DictionaryEntry {
  word: string;
  phonetic?: string;
  phonetics: Phonetic[];
  meanings: Meaning[];
  sourceUrls?: string[];
}

export class WordNotFoundError extends Error {
  constructor(public word: string) {
    super(`No definitions found for "${word}".`);
    this.name = "WordNotFoundError";
  }
}

const API_BASE = "https://api.dictionaryapi.dev/api/v2/entries/en";

export async function fetchDefinition(word: string): Promise<DictionaryEntry[]> {
  const trimmed = word.trim().toLowerCase();
  if (!trimmed) {
    throw new Error("Enter a word to look up.");
  }

  const res = await fetch(`${API_BASE}/${encodeURIComponent(trimmed)}`);

  if (res.status === 404) {
    throw new WordNotFoundError(trimmed);
  }
  if (!res.ok) {
    throw new Error("The dictionary is unreachable right now. Try again shortly.");
  }

  const data = (await res.json()) as DictionaryEntry[];
  return data;
}

/** Best available audio URL across all phonetics entries. */
export function getAudioUrl(entry: DictionaryEntry): string | null {
  const withAudio = entry.phonetics.find((p) => p.audio && p.audio.length > 0);
  return withAudio?.audio ?? null;
}

/** Best available phonetic text. */
export function getPhoneticText(entry: DictionaryEntry): string | null {
  if (entry.phonetic) return entry.phonetic;
  const withText = entry.phonetics.find((p) => p.text && p.text.length > 0);
  return withText?.text ?? null;
}
