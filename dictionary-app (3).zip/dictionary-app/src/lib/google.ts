/**
 * Server-only helper. This key must never be exposed to the client — it's
 * read inside API routes (app/api/**) which run on the server, and is used
 * for both Cloud Vision (OCR) and Cloud Translation REST calls.
 *
 * TEMPORARY: a hardcoded fallback is used below for local testing because
 * the GOOGLE_API_KEY environment variable wasn't being picked up. Revoke
 * this key in Google Cloud Console and switch back to env-var-only
 * (delete the fallback string) before deploying anywhere public or
 * pushing this repo to a public git host.
 */
const FALLBACK_KEY = "AIzaSyBm07Do31YEpbjAgpBSo5CGJPiL-6iPty4";

export function getGoogleApiKey(): string {
  const key = process.env.GOOGLE_API_KEY || FALLBACK_KEY;
  if (!key) {
    throw new Error("GOOGLE_API_KEY is not configured.");
  }
  return key;
}
