"use client";

import { useState } from "react";
import { LANGUAGES } from "@/lib/languages";

export default function TranslatePanel({
  text,
  onClose,
}: {
  text: string;
  onClose: () => void;
}) {
  const [target, setTarget] = useState("es");
  const [result, setResult] = useState<string | null>(null);
  const [detected, setDetected] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState("");

  async function translate() {
    setStatus("loading");
    setError("");
    try {
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, target }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Translation failed.");
      setResult(data.translatedText);
      setDetected(data.detectedSourceLanguage);
      setStatus("idle");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Translation failed.");
    }
  }

  return (
    <div className="mt-4 animate-fade-up border border-rule bg-paper px-4 py-3.5 dark:border-rule-dark dark:bg-paper-dark">
      <div className="flex items-center justify-between gap-3">
        <p className="font-mono text-xs uppercase tracking-[0.16em] text-moss dark:text-mossdark">
          Translate
        </p>
        <button
          onClick={onClose}
          aria-label="Close translate panel"
          className="text-ink-soft hover:text-stamp dark:text-ink-darksoft dark:hover:text-mossdark"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M6 6l12 12M18 6 6 18" />
          </svg>
        </button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <label className="sr-only" htmlFor="target-lang">
          Target language
        </label>
        <select
          id="target-lang"
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          className="border border-rule bg-paper px-2 py-1.5 font-mono text-xs text-ink dark:border-rule-dark dark:bg-paper-dark dark:text-ink-dark"
        >
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>
              {l.name}
            </option>
          ))}
        </select>
        <button
          onClick={translate}
          disabled={status === "loading"}
          className="border border-ink px-3 py-1.5 font-mono text-xs uppercase tracking-widest text-ink transition-colors hover:bg-ink hover:text-paper disabled:opacity-50 dark:border-ink-dark dark:text-ink-dark dark:hover:bg-ink-dark dark:hover:text-paper-dark"
        >
          {status === "loading" ? "Translating…" : "Translate"}
        </button>
      </div>

      {status === "error" && (
        <p className="mt-2 font-mono text-xs text-stamp">{error}</p>
      )}

      {result && (
        <div className="mt-3 border-t border-dotted border-rule pt-3 dark:border-rule-dark">
          {detected && (
            <p className="font-mono text-[11px] uppercase tracking-widest text-ink-soft dark:text-ink-darksoft">
              Detected source: {detected}
            </p>
          )}
          <p className="mt-1 whitespace-pre-wrap font-body text-[15px] leading-relaxed text-ink dark:text-ink-dark">
            {result}
          </p>
        </div>
      )}
    </div>
  );
}
