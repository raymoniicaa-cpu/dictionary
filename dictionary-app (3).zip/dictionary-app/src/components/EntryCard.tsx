"use client";

import { useRef, useState } from "react";
import {
  DictionaryEntry,
  getAudioUrl,
  getPhoneticText,
} from "@/lib/dictionary";
import TranslatePanel from "@/components/TranslatePanel";

const POS_LABELS: Record<string, string> = {
  noun: "n.",
  verb: "v.",
  adjective: "adj.",
  adverb: "adv.",
  pronoun: "pron.",
  preposition: "prep.",
  conjunction: "conj.",
  interjection: "interj.",
  exclamation: "exclam.",
};

export default function EntryCard({
  entry,
  isFavorite,
  onToggleFavorite,
}: {
  entry: DictionaryEntry;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [copied, setCopied] = useState(false);
  const [showTranslate, setShowTranslate] = useState(false);
  const audioUrl = getAudioUrl(entry);
  const phonetic = getPhoneticText(entry);

  const translateSource = [
    entry.word,
    ...entry.meanings.flatMap((m) => m.definitions.slice(0, 2).map((d) => d.definition)),
  ].join(". ");

  function playAudio() {
    if (!audioUrl) return;
    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
    }
    audioRef.current.currentTime = 0;
    audioRef.current.play().catch(() => {});
  }

  async function handleShare() {
    const url = `${window.location.origin}/?w=${encodeURIComponent(entry.word)}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: entry.word, url });
        return;
      } catch {
        // fall through to copy
      }
    }
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  async function handleCopyDefinition() {
    const lines = [entry.word, phonetic ? `/${phonetic.replace(/\//g, "")}/` : null]
      .filter(Boolean)
      .join(" ");
    const body = entry.meanings
      .map((m) => {
        const defs = m.definitions
          .slice(0, 3)
          .map((d, i) => `  ${i + 1}. ${d.definition}`)
          .join("\n");
        return `${m.partOfSpeech}\n${defs}`;
      })
      .join("\n\n");
    await navigator.clipboard.writeText(`${lines}\n\n${body}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  return (
    <article className="relative animate-fade-up">
      {isFavorite && (
        <div
          aria-hidden
          className="pointer-events-none absolute -right-2 top-0 z-10 -rotate-6 animate-stamp-in font-mono text-[11px] font-bold uppercase tracking-widest text-stamp/80 sm:right-2"
        >
          <div className="rounded-sm border-2 border-stamp/70 px-2 py-1">
            On your shelf
          </div>
        </div>
      )}

      <header className="flex flex-wrap items-end justify-between gap-x-6 gap-y-2 border-b border-rule pb-4 dark:border-rule-dark">
        <div>
          <h1 className="font-display text-4xl font-semibold leading-none text-ink dark:text-ink-dark sm:text-5xl">
            {entry.word}
          </h1>
          {phonetic && (
            <p className="mt-2 font-mono text-sm text-ink-soft dark:text-ink-darksoft">
              /{phonetic.replace(/\//g, "")}/
            </p>
          )}
        </div>
        <div className="flex items-center gap-1.5 pb-1">
          {audioUrl && (
            <IconButton label="Play pronunciation" onClick={playAudio}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z" />
              </svg>
            </IconButton>
          )}
          <IconButton
            label={isFavorite ? "Remove from shelf" : "Add to shelf"}
            onClick={onToggleFavorite}
            active={isFavorite}
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill={isFavorite ? "currentColor" : "none"}
              stroke="currentColor"
              strokeWidth="1.6"
            >
              <path d="M5 4.5A1.5 1.5 0 0 1 6.5 3h11A1.5 1.5 0 0 1 19 4.5V21l-7-4-7 4V4.5z" />
            </svg>
          </IconButton>
          <IconButton label="Copy definition" onClick={handleCopyDefinition}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <rect x="8" y="8" width="12" height="12" rx="1" />
              <path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" />
            </svg>
          </IconButton>
          <IconButton label="Share this word" onClick={handleShare}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <circle cx="18" cy="5" r="2.4" />
              <circle cx="6" cy="12" r="2.4" />
              <circle cx="18" cy="19" r="2.4" />
              <path d="M8.2 10.8 15.8 6.2M8.2 13.2l7.6 4.6" />
            </svg>
          </IconButton>
          <IconButton
            label={showTranslate ? "Hide translation" : "Translate this entry"}
            onClick={() => setShowTranslate((s) => !s)}
            active={showTranslate}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M4 5h9M8.5 3v2.2M5.5 5c.3 3.6 2.4 6.3 5.5 8M11.5 5c-.6 3.9-3 7-7 9" />
              <path d="m14 20 4-9 4 9M15.4 17h5.2" />
            </svg>
          </IconButton>
        </div>
      </header>

      {showTranslate && (
        <TranslatePanel text={translateSource} onClose={() => setShowTranslate(false)} />
      )}

      {copied && (
        <p className="mt-2 font-mono text-xs text-moss dark:text-mossdark">Copied to clipboard.</p>
      )}

      <div className="mt-6 flex flex-col gap-7">
        {entry.meanings.map((meaning, mi) => (
          <section key={mi}>
            <h2 className="font-mono text-xs uppercase tracking-[0.16em] text-moss dark:text-mossdark">
              {POS_LABELS[meaning.partOfSpeech] ?? meaning.partOfSpeech}
              <span className="ml-2 text-ink-soft dark:text-ink-darksoft">{meaning.partOfSpeech}</span>
            </h2>
            <ol className="mt-3 flex flex-col gap-3">
              {meaning.definitions.map((def, di) => (
                <li key={di} className="flex gap-3">
                  <span className="mt-[2px] shrink-0 font-mono text-xs text-ink-soft dark:text-ink-darksoft">
                    {di + 1}
                  </span>
                  <div>
                    <p className="font-body text-[15px] leading-relaxed text-ink dark:text-ink-dark">
                      {def.definition}
                    </p>
                    {def.example && (
                      <p className="mt-1 font-body text-[15px] italic leading-relaxed text-ink-soft dark:text-ink-darksoft">
                        &ldquo;{def.example}&rdquo;
                      </p>
                    )}
                    {(def.synonyms.length > 0 || def.antonyms.length > 0) && (
                      <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 font-mono text-xs">
                        {def.synonyms.length > 0 && (
                          <span className="text-ink-soft dark:text-ink-darksoft">
                            syn: {def.synonyms.slice(0, 5).join(", ")}
                          </span>
                        )}
                        {def.antonyms.length > 0 && (
                          <span className="text-ink-soft dark:text-ink-darksoft">
                            ant: {def.antonyms.slice(0, 5).join(", ")}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </li>
              ))}
            </ol>
            {(meaning.synonyms.length > 0 || meaning.antonyms.length > 0) && (
              <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 border-t border-dotted border-rule pt-3 font-mono text-xs dark:border-rule-dark">
                {meaning.synonyms.length > 0 && (
                  <span className="text-moss dark:text-mossdark">
                    synonyms: {meaning.synonyms.slice(0, 8).join(", ")}
                  </span>
                )}
                {meaning.antonyms.length > 0 && (
                  <span className="text-stamp/80">
                    antonyms: {meaning.antonyms.slice(0, 8).join(", ")}
                  </span>
                )}
              </div>
            )}
          </section>
        ))}
      </div>
    </article>
  );
}

function IconButton({
  children,
  label,
  onClick,
  active = false,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`flex h-8 w-8 items-center justify-center rounded-sm border transition-colors ${
        active
          ? "border-stamp text-stamp dark:border-mossdark dark:text-mossdark"
          : "border-rule text-ink-soft hover:border-stamp hover:text-stamp dark:border-rule-dark dark:text-ink-darksoft dark:hover:border-mossdark dark:hover:text-mossdark"
      }`}
    >
      {children}
    </button>
  );
}
