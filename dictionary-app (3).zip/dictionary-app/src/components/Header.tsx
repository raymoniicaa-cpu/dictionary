"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import ThemeToggle from "@/components/ThemeToggle";

const NAV = [
  { href: "/", label: "Look up" },
  { href: "/scan", label: "Scan" },
  { href: "/favorites", label: "Shelf" },
  { href: "/about", label: "About" },
];

export default function Header() {
  const pathname = usePathname();

  return (
    <header className="border-b border-rule dark:border-rule-dark">
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-3 px-5 pb-4 pt-6 sm:px-8">
        <div className="flex items-baseline justify-between">
          <Link href="/" className="group flex items-baseline gap-2">
            <span className="font-display text-3xl font-semibold tracking-tight text-ink dark:text-ink-dark sm:text-4xl">
              Lexicon
            </span>
            <span className="hidden font-mono text-[11px] uppercase tracking-[0.2em] text-ink-soft dark:text-ink-darksoft sm:inline">
              vol. I &middot; English
            </span>
          </Link>
          <ThemeToggle />
        </div>
        <nav className="flex items-center gap-1 font-mono text-[11px] uppercase tracking-[0.14em]">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-sm px-2.5 py-1.5 transition-colors ${
                  active
                    ? "bg-ink text-paper dark:bg-ink-dark dark:text-paper-dark"
                    : "text-ink-soft hover:bg-rule/50 dark:text-ink-darksoft dark:hover:bg-rule-dark/50"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
