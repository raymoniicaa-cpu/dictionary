"use client";

export default function RecentSearches({
  history,
  onPick,
}: {
  history: string[];
  onPick: (word: string) => void;
}) {
  if (history.length === 0) return null;

  return (
    <div className="mt-4 flex flex-wrap items-center gap-1.5">
      <span className="mr-1 font-mono text-[11px] uppercase tracking-widest text-ink-soft dark:text-ink-darksoft">
        Recent
      </span>
      {history.slice(0, 8).map((word) => (
        <button
          key={word}
          onClick={() => onPick(word)}
          className="rounded-sm border border-rule px-2 py-1 font-mono text-xs text-ink-soft transition-colors hover:border-stamp hover:text-stamp dark:border-rule-dark dark:text-ink-darksoft dark:hover:border-mossdark dark:hover:text-mossdark"
        >
          {word}
        </button>
      ))}
    </div>
  );
}
