"use client";

import { useState } from "react";
import { ALPHABET, SEED_WORDS } from "@/lib/seedWords";

export default function AlphabetRail({
  onPick,
}: {
  onPick: (word: string) => void;
}) {
  const [open, setOpen] = useState<string | null>(null);

  return (
    <nav
      aria-label="Browse by letter"
      className="sticky top-4 hidden h-fit shrink-0 select-none flex-col items-center gap-[2px] border-r border-rule pr-3 font-mono text-[11px] text-ink-soft dark:border-rule-dark dark:text-ink-darksoft sm:flex"
    >
      {ALPHABET.map((letter) => (
        <div key={letter} className="relative">
          <button
            onMouseEnter={() => setOpen(letter)}
            onFocus={() => setOpen(letter)}
            onMouseLeave={() => setOpen((o) => (o === letter ? null : o))}
            onClick={() => onPick(SEED_WORDS[letter][0])}
            className={`flex h-5 w-5 items-center justify-center uppercase transition-colors hover:text-stamp dark:hover:text-mossdark ${
              open === letter ? "text-stamp dark:text-mossdark" : ""
            }`}
          >
            {letter}
          </button>
          {open === letter && (
            <div
              onMouseEnter={() => setOpen(letter)}
              onMouseLeave={() => setOpen(null)}
              className="absolute right-7 top-1/2 z-10 -translate-y-1/2 whitespace-nowrap rounded-sm border border-rule bg-paper px-2 py-1.5 shadow-sm dark:border-rule-dark dark:bg-paper-dark"
            >
              <ul className="flex flex-col gap-1">
                {SEED_WORDS[letter].map((w) => (
                  <li key={w}>
                    <button
                      onClick={() => {
                        onPick(w);
                        setOpen(null);
                      }}
                      className="font-body text-[13px] normal-case text-ink hover:text-stamp dark:text-ink-dark dark:hover:text-mossdark"
                    >
                      {w}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ))}
    </nav>
  );
}
