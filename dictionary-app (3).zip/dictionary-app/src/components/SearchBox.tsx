"use client";

import { FormEvent, useState } from "react";

export default function SearchBox({
  onSearch,
  initialValue = "",
  loading = false,
}: {
  onSearch: (word: string) => void;
  initialValue?: string;
  loading?: boolean;
}) {
  const [value, setValue] = useState(initialValue);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (value.trim()) onSearch(value.trim());
  }

  return (
    <form onSubmit={handleSubmit} className="group relative" role="search">
      <label htmlFor="word-search" className="sr-only">
        Search for a word
      </label>
      <input
        id="word-search"
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Look up a word…"
        autoComplete="off"
        spellCheck={false}
        className="w-full border-b-2 border-ink bg-transparent py-3 pr-12 font-display text-2xl text-ink placeholder:text-ink-soft/50 focus:outline-none dark:border-ink-dark dark:text-ink-dark dark:placeholder:text-ink-darksoft/50 sm:text-3xl"
      />
      <button
        type="submit"
        disabled={loading}
        aria-label="Search"
        className="absolute right-1 top-1/2 -translate-y-1/2 rounded-sm p-2 text-ink-soft transition-colors hover:text-stamp disabled:opacity-40 dark:text-ink-darksoft dark:hover:text-mossdark"
      >
        {loading ? (
          <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
            <circle
              cx="12"
              cy="12"
              r="9"
              stroke="currentColor"
              strokeWidth="2"
              strokeDasharray="40"
              strokeDashoffset="10"
              strokeLinecap="round"
            />
          </svg>
        ) : (
          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.2-3.2" />
          </svg>
        )}
      </button>
    </form>
  );
}
