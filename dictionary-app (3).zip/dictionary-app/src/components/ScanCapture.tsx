"use client";

import { ChangeEvent, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import TranslatePanel from "@/components/TranslatePanel";

type Status = "idle" | "loading" | "error" | "done";

export default function ScanCapture() {
  const fileRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const [preview, setPreview] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [words, setWords] = useState<string[]>([]);
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState("");
  const [showTranslate, setShowTranslate] = useState(false);

  function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setPreview(dataUrl);
      setShowTranslate(false);
      scan(dataUrl);
    };
    reader.onerror = () => {
      setStatus("error");
      setError("Couldn't read that file.");
    };
    reader.readAsDataURL(file);
  }

  async function scan(dataUrl: string) {
    setStatus("loading");
    setError("");
    setText("");
    setWords([]);
    try {
      const res = await fetch("/api/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: dataUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Couldn't read that image.");
      setText(data.text ?? "");
      setWords(data.words ?? []);
      setStatus("done");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Couldn't read that image.");
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => fileRef.current?.click()}
          className="border border-ink px-4 py-2 font-mono text-xs uppercase tracking-widest text-ink transition-colors hover:bg-ink hover:text-paper dark:border-ink-dark dark:text-ink-dark dark:hover:bg-ink-dark dark:hover:text-paper-dark"
        >
          {preview ? "Scan another photo" : "Choose a photo"}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFile}
          className="hidden"
        />
        <p className="font-mono text-[11px] uppercase tracking-widest text-ink-soft dark:text-ink-darksoft">
          a page, sign, label, or note
        </p>
      </div>

      {preview && (
        <div className="flex flex-col gap-6 sm:flex-row">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={preview}
            alt="Selected photo to scan"
            className="h-auto w-full max-w-[220px] shrink-0 border border-rule object-cover dark:border-rule-dark"
          />

          <div className="min-w-0 flex-1">
            {status === "loading" && (
              <p className="font-mono text-xs uppercase tracking-widest text-ink-soft dark:text-ink-darksoft">
                Reading the page…
              </p>
            )}

            {status === "error" && (
              <div className="border-l-2 border-stamp py-2 pl-4">
                <p className="font-body text-sm text-ink dark:text-ink-dark">{error}</p>
              </div>
            )}

            {status === "done" && (
              <>
                {text ? (
                  <>
                    <p className="font-mono text-xs uppercase tracking-[0.16em] text-moss dark:text-mossdark">
                      Detected text
                    </p>
                    <p className="mt-2 max-h-48 overflow-y-auto whitespace-pre-wrap border-l-2 border-rule pl-3 font-body text-[15px] leading-relaxed text-ink dark:border-rule-dark dark:text-ink-dark">
                      {text}
                    </p>

                    {words.length > 0 && (
                      <>
                        <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-ink-soft dark:text-ink-darksoft">
                          Tap a word to look it up
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {words.slice(0, 60).map((w) => (
                            <button
                              key={w}
                              onClick={() => router.push(`/?w=${encodeURIComponent(w)}`)}
                              className="rounded-sm border border-rule px-2 py-1 font-mono text-xs text-ink-soft transition-colors hover:border-stamp hover:text-stamp dark:border-rule-dark dark:text-ink-darksoft dark:hover:border-mossdark dark:hover:text-mossdark"
                            >
                              {w}
                            </button>
                          ))}
                        </div>
                      </>
                    )}

                    <button
                      onClick={() => setShowTranslate((s) => !s)}
                      className="mt-4 font-mono text-xs uppercase tracking-widest text-stamp underline decoration-stamp/40 underline-offset-4 hover:decoration-stamp"
                    >
                      {showTranslate ? "Hide translation" : "Translate this text"}
                    </button>

                    {showTranslate && (
                      <TranslatePanel text={text} onClose={() => setShowTranslate(false)} />
                    )}
                  </>
                ) : (
                  <p className="font-body text-sm text-ink-soft dark:text-ink-darksoft">
                    No text found in that photo. Try a clearer, well-lit shot, held flat to the
                    page.
                  </p>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
