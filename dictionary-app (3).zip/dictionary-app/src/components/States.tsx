export function EmptyState({ word }: { word?: string }) {
  return (
    <div className="animate-fade-up border-l-2 border-rule py-6 pl-5 dark:border-rule-dark">
      <p className="font-display text-xl text-ink dark:text-ink-dark">
        {word ? `No entry for "${word}".` : "Nothing here yet."}
      </p>
      <p className="mt-2 max-w-prose font-body text-sm text-ink-soft dark:text-ink-darksoft">
        {word
          ? "Check the spelling, or try a related word — the dictionary covers standard English headwords, not every proper noun or abbreviation."
          : "Search for a word above, or pick a letter from the index to see a few notable entries."}
      </p>
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="animate-fade-up border-l-2 border-stamp py-6 pl-5">
      <p className="font-display text-xl text-ink dark:text-ink-dark">Something went wrong.</p>
      <p className="mt-2 max-w-prose font-body text-sm text-ink-soft dark:text-ink-darksoft">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-3 font-mono text-xs uppercase tracking-widest text-stamp underline decoration-stamp/40 underline-offset-4 hover:decoration-stamp"
        >
          Try again
        </button>
      )}
    </div>
  );
}

export function LoadingState() {
  return (
    <div className="flex flex-col gap-4 py-2" aria-live="polite" aria-busy="true">
      <div className="h-9 w-48 animate-pulse rounded-sm bg-rule/60 dark:bg-rule-dark/60" />
      <div className="h-4 w-24 animate-pulse rounded-sm bg-rule/50 dark:bg-rule-dark/50" />
      <div className="mt-4 flex flex-col gap-2">
        <div className="h-4 w-full animate-pulse rounded-sm bg-rule/40 dark:bg-rule-dark/40" />
        <div className="h-4 w-5/6 animate-pulse rounded-sm bg-rule/40 dark:bg-rule-dark/40" />
        <div className="h-4 w-2/3 animate-pulse rounded-sm bg-rule/40 dark:bg-rule-dark/40" />
      </div>
      <span className="sr-only">Loading definition…</span>
    </div>
  );
}
