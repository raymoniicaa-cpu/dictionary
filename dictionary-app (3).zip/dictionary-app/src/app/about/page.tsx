export default function AboutPage() {
  return (
    <div className="flex animate-fade-up flex-col gap-5">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-ink-dark sm:text-4xl">
        About Lexicon
      </h1>
      <p className="max-w-prose font-body text-[15px] leading-relaxed text-ink dark:text-ink-dark">
        Lexicon is a small, fast dictionary that runs entirely in your browser. There is no account,
        no server-side database, and nothing about your searches leaves your device except the
        lookup itself, sent straight to the dictionary API.
      </p>
      <p className="max-w-prose font-body text-[15px] leading-relaxed text-ink dark:text-ink-dark">
        Definitions, pronunciations, and examples come from{" "}
        <a
          href="https://dictionaryapi.dev"
          target="_blank"
          rel="noreferrer"
          className="underline decoration-rule underline-offset-2 hover:text-stamp dark:hover:text-mossdark"
        >
          DictionaryAPI.dev
        </a>
        . The Scan &amp; Translate page sends a photo to Google Cloud Vision for text recognition,
        and any text you choose to translate to Google Cloud Translation — both only when you
        actively use those features. Favorites, recent searches, and your theme preference are
        kept in your browser&apos;s local storage — clear your site data and they&apos;re gone for
        good.
      </p>
      <div className="border-l-2 border-rule py-1 pl-5 dark:border-rule-dark">
        <h2 className="font-mono text-xs uppercase tracking-[0.16em] text-moss dark:text-mossdark">
          Built with
        </h2>
        <p className="mt-1 font-body text-sm text-ink-soft dark:text-ink-darksoft">
          Next.js, TypeScript, and Tailwind CSS, with Google Cloud Vision and Cloud Translation
          for the scan feature. Installable as a PWA — add it to your home screen for offline
          access to your shelf and recent history.
        </p>
      </div>
      <div className="border-l-2 border-rule py-1 pl-5 dark:border-rule-dark">
        <h2 className="font-mono text-xs uppercase tracking-[0.16em] text-moss dark:text-mossdark">
          What&apos;s next
        </h2>
        <p className="mt-1 font-body text-sm text-ink-soft dark:text-ink-darksoft">
          Plain-language AI explanations, flashcards, and quizzes are on the roadmap.
        </p>
      </div>
    </div>
  );
}
