import ScanCapture from "@/components/ScanCapture";

export default function ScanPage() {
  return (
    <div className="flex animate-fade-up flex-col gap-5">
      <div>
        <h1 className="font-display text-3xl font-semibold text-ink dark:text-ink-dark sm:text-4xl">
          Scan &amp; translate
        </h1>
        <p className="mt-2 max-w-prose font-body text-sm text-ink-soft dark:text-ink-darksoft">
          Photograph a page, sign, or label. Lexicon pulls out the text with Google Cloud Vision,
          lets you look up any English word it finds, and can translate the whole passage if it
          isn&apos;t in English.
        </p>
      </div>
      <ScanCapture />
    </div>
  );
}
