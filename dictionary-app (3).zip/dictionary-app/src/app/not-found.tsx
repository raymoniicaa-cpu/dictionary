import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex animate-fade-up flex-col items-start gap-3 py-10">
      <p className="font-mono text-xs uppercase tracking-widest text-stamp">404</p>
      <h1 className="font-display text-4xl font-semibold text-ink dark:text-ink-dark">
        Not in this dictionary.
      </h1>
      <p className="max-w-prose font-body text-sm text-ink-soft dark:text-ink-darksoft">
        That page doesn&apos;t exist. It might have been moved, or it was never a word to begin
        with.
      </p>
      <Link
        href="/"
        className="mt-2 font-mono text-xs uppercase tracking-widest text-stamp underline decoration-stamp/40 underline-offset-4 hover:decoration-stamp"
      >
        Back to the dictionary
      </Link>
    </div>
  );
}
