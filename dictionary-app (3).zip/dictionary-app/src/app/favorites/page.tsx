"use client";

import Link from "next/link";
import { useFavorites } from "@/lib/storage";

export default function FavoritesPage() {
  const { favorites, removeFavorite } = useFavorites();

  return (
    <div className="animate-fade-up">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-ink-dark sm:text-4xl">
        Your shelf
      </h1>
      <p className="mt-2 max-w-prose font-body text-sm text-ink-soft dark:text-ink-darksoft">
        Words you&apos;ve set aside, kept in this browser&apos;s storage. Clear your browser data and
        they&apos;ll go with it — nothing is sent anywhere else.
      </p>

      {favorites.length === 0 ? (
        <div className="mt-8 border-l-2 border-rule py-6 pl-5 dark:border-rule-dark">
          <p className="font-display text-xl text-ink dark:text-ink-dark">The shelf is empty.</p>
          <p className="mt-2 font-body text-sm text-ink-soft dark:text-ink-darksoft">
            Look up a word and tap the bookmark icon to keep it here.
          </p>
          <Link
            href="/"
            className="mt-3 inline-block font-mono text-xs uppercase tracking-widest text-stamp underline decoration-stamp/40 underline-offset-4 hover:decoration-stamp"
          >
            Go look something up
          </Link>
        </div>
      ) : (
        <ul className="mt-8 flex flex-col">
          {favorites.map((word) => (
            <li
              key={word}
              className="flex items-center justify-between border-b border-rule py-3 dark:border-rule-dark"
            >
              <Link
                href={`/?w=${encodeURIComponent(word)}`}
                className="font-display text-xl text-ink hover:text-stamp dark:text-ink-dark dark:hover:text-mossdark"
              >
                {word}
              </Link>
              <button
                onClick={() => removeFavorite(word)}
                aria-label={`Remove ${word} from shelf`}
                className="font-mono text-xs uppercase tracking-widest text-ink-soft hover:text-stamp dark:text-ink-darksoft dark:hover:text-mossdark"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
