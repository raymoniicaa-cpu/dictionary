import type { Metadata, Viewport } from "next";
import { Fraunces, Source_Serif_4, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  axes: ["opsz", "SOFT", "WONK"],
  display: "swap",
});

const sourceSerif = Source_Serif_4({
  subsets: ["latin"],
  variable: "--font-source-serif",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Lexicon — a dictionary worth reading",
  description:
    "Look up words, hear them spoken, and keep a shelf of favorites. Fast, offline-friendly, no account needed.",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Lexicon",
  },
  icons: {
    icon: "/icon.svg",
    apple: "/icon.svg",
  },
};

export const viewport: Viewport = {
  themeColor: "#F7F3E9",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${fraunces.variable} ${sourceSerif.variable} ${jetbrains.variable} font-body paper-texture min-h-screen antialiased`}
      >
        <Header />
        <main className="mx-auto w-full max-w-4xl px-5 pb-24 pt-8 sm:px-8">
          {children}
        </main>
        <footer className="mx-auto w-full max-w-4xl px-5 pb-12 pt-6 text-center text-xs text-ink-soft dark:text-ink-darksoft sm:px-8">
          <p>
            Definitions courtesy of{" "}
            <a
              href="https://dictionaryapi.dev"
              target="_blank"
              rel="noreferrer"
              className="underline decoration-rule underline-offset-2 hover:text-stamp dark:hover:text-mossdark"
            >
              DictionaryAPI.dev
            </a>
            . No account, no tracking, no database — just your browser.
          </p>
        </footer>
      </body>
    </html>
  );
}
