"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import SearchBox from "@/components/SearchBox";
import AlphabetRail from "@/components/AlphabetRail";
import EntryCard from "@/components/EntryCard";
import RecentSearches from "@/components/RecentSearches";
import { EmptyState, ErrorState, LoadingState } from "@/components/States";
import { DictionaryEntry, fetchDefinition, WordNotFoundError } from "@/lib/dictionary";
import { useFavorites, useHistory } from "@/lib/storage";
import { wordOfTheDay } from "@/lib/seedWords";

function HomeContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialWord = searchParams.get("w") ?? "";

  const [entries, setEntries] = useState<DictionaryEntry[] | null>(null);
  const [activeWord, setActiveWord] = useState<string>(initialWord);
  const [status, setStatus] = useState<"idle" | "loading" | "error" | "notfound" | "done">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const { isFavorite, toggleFavorite } = useFavorites();
  const { history, addToHistory } = useHistory();

  const runSearch = useCallback(
    async (word: string) => {
      setActiveWord(word);
      setStatus("loading");
      router.replace(`/?w=${encodeURIComponent(word)}`, { scroll: false });
      try {
        const data = await fetchDefinition(word);
        setEntries(data);
        setStatus("done");
        addToHistory(word);
      } catch (err) {
        setEntries(null);
        if (err instanceof WordNotFoundError) {
          setStatus("notfound");
        } else {
          setStatus("error");
          setErrorMessage(err instanceof Error ? err.message : "Unexpected error.");
        }
      }
    },
    [router, addToHistory]
  );

  useEffect(() => {
    if (initialWord) {
      runSearch(initialWord);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex gap-8">
      <AlphabetRail onPick={runSearch} />

      <div className="min-w-0 flex-1">
        {status === "idle" && (
          <div className="mb-8">
            <p className="font-mono text-xs uppercase tracking-[0.18em] text-ink-soft dark:text-ink-darksoft">
              Word of the day
            </p>
            <button
              onClick={() => runSearch(wordOfTheDay())}
              className="mt-1 font-display text-3xl text-ink underline decoration-rule decoration-2 underline-offset-4 transition-colors hover:decoration-stamp dark:text-ink-dark dark:hover:decoration-mossdark"
            >
              {wordOfTheDay()}
            </button>
          </div>
        )}

        <SearchBox onSearch={runSearch} initialValue={initialWord} loading={status === "loading"} />
        <RecentSearches history={history} onPick={runSearch} />

        <div className="mt-8">
          {status === "loading" && <LoadingState />}
          {status === "error" && <ErrorState message={errorMessage} onRetry={() => runSearch(activeWord)} />}
          {status === "notfound" && <EmptyState word={activeWord} />}
          {status === "idle" && <EmptyState />}
          {status === "done" && entries && entries.length > 0 && (
            <div className="flex flex-col gap-10">
              {entries.map((entry, i) => (
                <EntryCard
                  key={i}
                  entry={entry}
                  isFavorite={isFavorite(entry.word)}
                  onToggleFavorite={() => toggleFavorite(entry.word)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <Suspense fallback={<LoadingState />}>
      <HomeContent />
    </Suspense>
  );
}
