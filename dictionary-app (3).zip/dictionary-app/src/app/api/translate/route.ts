import { NextRequest, NextResponse } from "next/server";
import { getGoogleApiKey } from "@/lib/google";

export const runtime = "nodejs";

const MAX_TEXT_LENGTH = 5000;

export async function POST(req: NextRequest) {
  let body: { text?: string; target?: string; source?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { text, target, source } = body;
  if (!text || !target) {
    return NextResponse.json({ error: "Text and a target language are required." }, { status: 400 });
  }
  if (text.length > MAX_TEXT_LENGTH) {
    return NextResponse.json({ error: "That text is too long to translate at once." }, { status: 413 });
  }

  let apiKey: string;
  try {
    apiKey = getGoogleApiKey();
  } catch {
    return NextResponse.json(
      {
        error:
          "Translation isn't configured yet. Add a GOOGLE_API_KEY environment variable with Cloud Translation enabled.",
      },
      { status: 501 }
    );
  }

  const params = new URLSearchParams({
    q: text,
    target,
    format: "text",
    key: apiKey,
  });
  if (source) params.set("source", source);

  let translateRes: Response;
  try {
    translateRes = await fetch(
      `https://translation.googleapis.com/language/translate/v2?${params.toString()}`,
      { method: "POST" }
    );
  } catch {
    return NextResponse.json(
      { error: "Couldn't reach the translation service. Check your connection and try again." },
      { status: 502 }
    );
  }

  if (!translateRes.ok) {
    return NextResponse.json(
      { error: "The translation service couldn't process that text." },
      { status: 502 }
    );
  }

  const data = await translateRes.json();
  const translation = data.data?.translations?.[0];

  if (!translation) {
    return NextResponse.json({ error: "No translation was returned." }, { status: 502 });
  }

  return NextResponse.json({
    translatedText: translation.translatedText as string,
    detectedSourceLanguage: (translation.detectedSourceLanguage as string) ?? source ?? null,
  });
}
