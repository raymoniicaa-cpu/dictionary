import { NextRequest, NextResponse } from "next/server";
import { getGoogleApiKey } from "@/lib/google";

export const runtime = "nodejs";

// Roughly caps the original image around ~5MB before base64 inflation.
const MAX_BASE64_LENGTH = 7_000_000;

export async function POST(req: NextRequest) {
  let body: { image?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const image = body.image;
  if (!image || typeof image !== "string") {
    return NextResponse.json({ error: "No image provided." }, { status: 400 });
  }

  // Accept either a raw base64 string or a data URL (data:image/jpeg;base64,...)
  const base64 = image.includes(",") ? image.split(",")[1] : image;

  if (!base64 || base64.length > MAX_BASE64_LENGTH) {
    return NextResponse.json(
      { error: "That image is too large. Try a smaller or more compressed photo." },
      { status: 413 }
    );
  }

  let apiKey: string;
  try {
    apiKey = getGoogleApiKey();
  } catch {
    return NextResponse.json(
      {
        error:
          "Scanning isn't configured yet. Add a GOOGLE_API_KEY environment variable with Cloud Vision enabled.",
      },
      { status: 501 }
    );
  }

  let visionRes: Response;
  try {
    visionRes = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        requests: [
          {
            image: { content: base64 },
            features: [{ type: "TEXT_DETECTION" }],
          },
        ],
      }),
    });
  } catch {
    return NextResponse.json(
      { error: "Couldn't reach the vision service. Check your connection and try again." },
      { status: 502 }
    );
  }

  if (!visionRes.ok) {
    return NextResponse.json(
      { error: "The vision service couldn't process that image." },
      { status: 502 }
    );
  }

  const data = await visionRes.json();
  const firstResponse = data.responses?.[0];

  if (firstResponse?.error) {
    return NextResponse.json(
      { error: firstResponse.error.message || "The vision service rejected that image." },
      { status: 502 }
    );
  }

  const text: string = firstResponse?.fullTextAnnotation?.text ?? "";

  if (!text.trim()) {
    return NextResponse.json({ text: "", words: [] });
  }

  const words = Array.from(
    new Set(
      text
        .split(/[^A-Za-z'-]+/)
        .map((w) => w.trim().toLowerCase())
        .filter((w) => w.length > 1)
    )
  );

  return NextResponse.json({ text, words });
}
